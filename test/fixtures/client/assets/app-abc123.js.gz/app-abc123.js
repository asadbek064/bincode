console.log("asset stub");
